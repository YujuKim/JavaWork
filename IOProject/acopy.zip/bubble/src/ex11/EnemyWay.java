package ex11;

public enum EnemyWay {
	LEFT, RIGHT

}
