package ex09;

public enum EnemyWay {
	LEFT, RIGHT

}
