module bubble {
	requires java.desktop;
}