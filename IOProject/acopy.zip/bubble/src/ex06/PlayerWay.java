package ex06;

//enum타입을 사용하는 이유
//1. 가독성
//2. 데이터의 범주화가 필요할 때 

public enum PlayerWay {
	LEFT, RIGHT

}
