package ex10;

public enum EnemyWay {
	LEFT, RIGHT

}
